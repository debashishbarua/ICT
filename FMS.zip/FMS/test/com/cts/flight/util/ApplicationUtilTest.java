/**
 * 
 */
package com.cts.flight.util;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cts.flight.exception.FlightScheduleAdminSystemException;

/**
 * @author Debashish
 *
 */
public class ApplicationUtilTest {

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeAll
	public static void setUpBeforeClass() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterAll
	public static void tearDownAfterClass() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeEach
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterEach
	public void tearDown() throws Exception {
	}

	/**
	 * Test method for
	 * {@link com.cts.flight.util.ApplicationUtil#readFile(java.lang.String)}.
	 * 
	 * @throws FlightScheduleAdminSystemException
	 */
	@Test
	public void testReadFileWithWrongFileName() throws FlightScheduleAdminSystemException {
		ApplicationUtil.readFile("wrongInputFeed.txt");
		fail("Please check if the input file name . Actual Result - No Exception, Expecting Custom exception ");
	}

	/**
	 * Test method for
	 * {@link com.cts.flight.util.ApplicationUtil#readFile(java.lang.String)}.
	 * 
	 * @throws FlightScheduleAdminSystemException
	 */
	@Test
	public void testReadFileForAirFlightSchedule() throws FlightScheduleAdminSystemException {
		List<String> list = ApplicationUtil.readFile("inputFeed.txt");
		if (list.size() > 1) {
			assert (true);
		} else {
			fail("Plese check the logic for readFile");
		}
	}

	/**
	 * Test method for
	 * {@link com.cts.flight.util.ApplicationUtil#convertUtilToSqlDate(java.util.Date)}.
	 */
	@Test
	public void testConvertUtilToSqlDate() {
		Date uDate = new Date();
		java.sql.Date sDate = ApplicationUtil.convertUtilToSqlDate(uDate);
		if (sDate instanceof java.sql.Date)
			assert (true);
		else
			fail("Plese check the logic for converting java.util.Date to java.sql.Date");
	}

	/**
	 * Test method for
	 * {@link com.cts.flight.util.ApplicationUtil#convertUtilToSqlTime(java.util.Date)}.
	 */
	@Test
	public void testConvertUtilToSqlTime() {
		Date uDate = new Date();
		java.sql.Time sDate = ApplicationUtil.convertUtilToSqlTime(uDate);
		if (sDate instanceof java.sql.Time)
			assert (true);
		else
			fail("Plese check the logic for converting java.util.Date to java.sql.Time");

	}

	/**
	 * Test method for
	 * {@link com.cts.flight.util.ApplicationUtil#convertStringToTime(java.lang.String)}.
	 */
	@Test
	public void testConvertStringToTime() {
		String inDate = "10:10:10";
		Date outDate = ApplicationUtil.convertStringToTime(inDate);
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(outDate);
		if (calendar.get(Calendar.HOUR) == 10 && calendar.get(Calendar.MINUTE) == 10
				&& +calendar.get(Calendar.SECOND) == 10) {
			assertTrue(true);
		} else {
			fail("Plese check the logic for converting String to Time");
		}
	}

	/**
	 * Test method for
	 * {@link com.cts.flight.util.ApplicationUtil#convertStringToDate(java.lang.String)}.
	 */
	@Test
	public void testConvertStringToDate() {
		String inDate = "2018-11-11";
		Date outDate = ApplicationUtil.convertStringToDate(inDate);
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(outDate);
		if (calendar.get(Calendar.YEAR) == 2018 && calendar.get(Calendar.MONTH) == 10
				&& +calendar.get(Calendar.DATE) == 11) {
			assertTrue(true);
		} else {
			fail("Plese check the logic for converting String to Date");
		}

	}

	/**
	 * Test method for
	 * {@link com.cts.flight.util.ApplicationUtil#timeDifference(java.util.Date, java.util.Date)}.
	 */
	@Test
	public void testTimeDifference() {
		Date time1 = ApplicationUtil.convertStringToTime("14:10:05");
		Date time2 = ApplicationUtil.convertStringToTime("16:12:10");
		Date timeDiff = ApplicationUtil.timeDifference(time1, time2);
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(timeDiff);
		if (calendar.get(Calendar.HOUR) == 2 && calendar.get(Calendar.MINUTE) == 2
				&& +calendar.get(Calendar.SECOND) == 5) {
			assertTrue(true);
		} else {
			fail("Plese check the logic for time difference");
		}
	}

}

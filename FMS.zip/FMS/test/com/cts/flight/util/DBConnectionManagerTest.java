/**
 * 
 */
package com.cts.flight.util;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.sql.Connection;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cts.flight.exception.FlightScheduleAdminSystemException;

/**
 * @author Debashish
 *
 */
public class DBConnectionManagerTest {

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeAll
	public static void setUpBeforeClass() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterAll
	public static void tearDownAfterClass() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeEach
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterEach
	public void tearDown() throws Exception {
	}

	/**
	 * Test method for {@link com.cts.flight.util.DBConnectionManager#getConnection()}.
	 * @throws FlightScheduleAdminSystemException 
	 */
	@Test
	public void testGetConnection() throws FlightScheduleAdminSystemException {
		Connection connection=DBConnectionManager.getInstance().getConnection();
		if(connection instanceof java.sql.Connection && connection!=null){
			assertTrue(true);
		}else{
			fail("Plese check the logic for get Connection");
		}
	}

}

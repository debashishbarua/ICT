/**
 * 
 */
package com.cts.flight.service;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.fail;

/**
 * @author Debashish
 *
 */
public class AirFlightAdminServiceTest {

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeAll
	public static void setUpBeforeClass() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterAll
	public static void tearDownAfterClass() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeEach
	public void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterEach
	public void tearDown() throws Exception {
	}

	/**
	 * Test method for {@link com.cts.flight.service.AirFlightAdminService#buildAirFlightScheduleList(java.util.List)}.
	 */
	@Test
	public void testBuildAirFlightScheduleList() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link com.cts.flight.service.AirFlightAdminService#addAirFlightSchedules(java.lang.String)}.
	 */
	@Test
	public void testAddAirFlightSchedules() {
		fail("Not yet implemented");
	}

}

package com.cts.flight.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import com.cts.flight.exception.FlightScheduleAdminSystemException;
import com.cts.flight.util.DBConnectionManager;
import com.cts.flight.vo.AirFlightSchedule;

public class AirFlightScheduleDaoTestUtil {

	private static Connection conn = null;	

	public static final String DELETE_AIRFLIGHTDETAILS_DETAILS = "DELETE FROM AIR_FLIGHT_DETAILS WHERE FLIGHT_ID=?";

	
	
	public Boolean daleteAirFlightSchedules(List<AirFlightSchedule> flights) throws FlightScheduleAdminSystemException {
		// TODO add your code here
		Boolean status = false;
		try {
			conn = DBConnectionManager.getInstance().getConnection();
			conn.setAutoCommit(false);
			PreparedStatement psAdd = conn.prepareStatement(DELETE_AIRFLIGHTDETAILS_DETAILS);
			for (AirFlightSchedule flight : flights) {
				psAdd.setString(1, flight.getFlightId());				
				psAdd.addBatch();
			}

			int[] rows = psAdd.executeBatch();
			if (rows != null && rows.length > 0) {
				status = true;
			}
			conn.commit();
		} catch (SQLException ex) {
			if (conn != null) {
				try {
					conn.rollback();
				} catch (SQLException e) {
					throw new FlightScheduleAdminSystemException(ex.getMessage(), ex.getCause());
				}
			}
			throw new FlightScheduleAdminSystemException(ex.getMessage(), ex.getCause());
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					throw new FlightScheduleAdminSystemException(e.getMessage(), e.getCause());
				}
			}
		}

		return status;
		// TODO CHANGE THIS RETURN TYPE

	}

}
/**
 * 
 */
package com.cts.flight.dao;

import static org.junit.jupiter.api.Assertions.fail;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cts.flight.exception.FlightScheduleAdminSystemException;
import com.cts.flight.util.ApplicationUtil;
import com.cts.flight.vo.AirFlightSchedule;

/**
 * @author Debashish
 *
 */
public class AirFlightScheduleDaoTest {

	private static AirFlightScheduleDao dao;
	private static List<AirFlightSchedule> flightSchedules = new ArrayList<AirFlightSchedule>();
	private AirFlightScheduleDaoTestUtil daoTestUtil = new AirFlightScheduleDaoTestUtil();

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeAll
	public static void setUpBeforeClass() throws Exception {
		dao = new AirFlightScheduleDao();
		flightSchedules.add(new AirFlightSchedule("AF001", ApplicationUtil.convertStringToDate("2020-06-06"),
				ApplicationUtil.convertStringToTime("12:10:00"), ApplicationUtil.convertStringToTime("14:10:00"),
				ApplicationUtil.convertStringToTime("02:00:00"), 4500.00, 40));
		flightSchedules.add(new AirFlightSchedule("AF002", ApplicationUtil.convertStringToDate("2020-06-06"),
				ApplicationUtil.convertStringToTime("12:10:00"), ApplicationUtil.convertStringToTime("14:10:00"),
				ApplicationUtil.convertStringToTime("02:00:00"), 4500.00, 40));
		flightSchedules.add(new AirFlightSchedule("AF003", ApplicationUtil.convertStringToDate("2020-06-06"),
				ApplicationUtil.convertStringToTime("12:10:00"), ApplicationUtil.convertStringToTime("14:10:00"),
				ApplicationUtil.convertStringToTime("02:00:00"), 4500.00, 40));

	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterAll
	public static void tearDownAfterClass() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeEach
	public void setUp() throws Exception {

	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterEach
	public void tearDown() throws Exception {
	}

	/**
	 * Test method for
	 * {@link com.cts.flight.dao.AirFlightScheduleDao#insertAirFlightSchedules(java.util.List)}.
	 * 
	 * @throws FlightScheduleAdminSystemException
	 */
	@Test
	public void testInsertAirFlightSchedules() throws FlightScheduleAdminSystemException {
		Boolean status = dao.insertAirFlightSchedules(flightSchedules);
		if (status) {
			assert (true);
		} else {
			fail("Please check the logic for insertAirFlightSchedules");
		}

	}

	/**
	 * Test method for
	 * {@link com.cts.flight.dao.AirFlightScheduleDao#updateAirFlightSchedules(java.util.List)}.
	 * 
	 * @throws FlightScheduleAdminSystemException
	 */
	@Test
	//@Order(2)
	public void testUpdateAirFlightSchedules() throws FlightScheduleAdminSystemException {
		Boolean status = dao.updateAirFlightSchedules(flightSchedules);
		if (status) {
			assert (true);
		} else {
			fail("Please check the logic for updateAirFlightSchedules");
		}
	}

	/**
	 * Test method for
	 * {@link com.cts.flight.dao.AirFlightScheduleDao#findAirFlightSchedules(com.cts.flight.vo.AirFlightSchedule)}.
	 * 
	 * @throws FlightScheduleAdminSystemException
	 */
	/*
	 * @Test
	 * 
	 * @Order(3) public void testFindAirFlightSchedules() throws
	 * FlightScheduleAdminSystemException { Boolean status =
	 * dao.findAirFlightSchedules(flightSchedules.get(0)); if (status) { assert
	 * (true); } else { fail("Please check the logic for findAirFlightSchedules"); }
	 * daoTestUtil.daleteAirFlightSchedules(flightSchedules); }
	 */

}

/***********************************************************************************************************
 * This class AirFlightScheduleDao is used to persist or retrieve data from database.
 * 
 * DO NOT CHANGE THE CLASS NAME,  PUBLIC METHODS, SIGNATURE OF METHODS, EXCEPTION CLAUSES, RETURN TYPES
 * YOU CAN ADD ANY NUMBER OF PRIVATE METHODS TO MODULARIZE THE CODE
 * DO NOT SUBMIT THE CODE WITH COMPILATION ERRORS
 * DO TEST YOUR CODE USING MAIN METHOD 
 * CHANGE THE RETURN TYPE OF THE METHODS ONCE YOU BUILT THE LOGIC
 * DO NOT ADD ANY ADDITIONAL EXCEPTIONS IN THE THROWS CLAUSE OF THE METHOD. IF NEED BE, 
 * YOU CAN CATCH THEM AND THROW ONLY 
 * THE APPLICATION SPECIFIC EXCEPTION AS PER EXCEPTION CLAUSE
 *
************************************************************************************************************/


package com.cts.flight.dao;

import java.sql.Connection;
import java.util.List;

import com.cts.flight.exception.FlightScheduleAdminSystemException;
import com.cts.flight.vo.AirFlight;

public class AirFlightDao {
	
	private static Connection conn = null;

	public Boolean addAirFlightRecords(List<AirFlight> flights) throws FlightScheduleAdminSystemException {
		//TODO add your code here
		return false; 	//TODO CHANGE THIS RETURN TYPE

	}
}

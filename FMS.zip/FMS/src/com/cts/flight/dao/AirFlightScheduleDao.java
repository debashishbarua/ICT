/***********************************************************************************************************
 * This class AirFlightScheduleDao is used to persist or retrieve data from database.
 * 
 * DO NOT CHANGE THE CLASS NAME,  PUBLIC METHODS, SIGNATURE OF METHODS, EXCEPTION CLAUSES, RETURN TYPES
 * YOU CAN ADD ANY NUMBER OF PRIVATE METHODS TO MODULARIZE THE CODE
 * DO NOT SUBMIT THE CODE WITH COMPILATION ERRORS
 * DO TEST YOUR CODE USING MAIN METHOD 
 * CHANGE THE RETURN TYPE OF THE METHODS ONCE YOU BUILT THE LOGIC
 * DO NOT ADD ANY ADDITIONAL EXCEPTIONS IN THE THROWS CLAUSE OF THE METHOD. IF NEED BE, 
 * YOU CAN CATCH THEM AND THROW ONLY 
 * THE APPLICATION SPECIFIC EXCEPTION AS PER EXCEPTION CLAUSE
 *
************************************************************************************************************/

package com.cts.flight.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.cts.flight.exception.FlightScheduleAdminSystemException;
import com.cts.flight.util.ApplicationUtil;
import com.cts.flight.util.DBConnectionManager;
import com.cts.flight.vo.AirFlightSchedule;

public class AirFlightScheduleDao {

	private static Connection conn = null;	

	public static final String ADD_AIRFLIGHTDETAILS_DETAILS = "INSERT INTO AIR_FLIGHT_DETAILS"
			+ "(FLIGHT_ID,FLIGHT_DEPARTURE_DATE, DEPARTURE_TIME, ARRIVAL_TIME, DURATION, PRICE,AVAILABLE_SEATS) "
			+ "VALUES(?,?,?,?,?,?,?)";

	public static final String UPDATE_AIRFLIGHTDETAILS_DETAILS = "UPDATE AIR_FLIGHT_DETAILS"
			+ " SET DEPARTURE_TIME=?, ARRIVAL_TIME=?, DURATION=? " + "WHERE FLIGHT_ID=? AND FLIGHT_DEPARTURE_DATE=?";

	public static final String FIND_AIRFLIGHTDETAILS_BY_DAPARTURE_DATE_TIME = "SELECT COUNT(*) FROM AIR_FLIGHT_DETAILS"
			+ " WHERE FLIGHT_ID=? AND FLIGHT_DEPARTURE_DATE=?";

	
	
	public Boolean insertAirFlightSchedules(List<AirFlightSchedule> flights) throws FlightScheduleAdminSystemException {
		// TODO add your code here
		Boolean status = false;
		try {
			conn = DBConnectionManager.getInstance().getConnection();
			conn.setAutoCommit(false);
			PreparedStatement psAdd = conn.prepareStatement(ADD_AIRFLIGHTDETAILS_DETAILS);
			for (AirFlightSchedule flight : flights) {
				psAdd.setString(1, flight.getFlightId());
				psAdd.setDate(2, ApplicationUtil.convertUtilToSqlDate(flight.getFlightDepartureDate()));
				psAdd.setTime(3, ApplicationUtil.convertUtilToSqlTime(flight.getDepartureTime()));
				psAdd.setTime(4, ApplicationUtil.convertUtilToSqlTime(flight.getArrivalTime()));
				psAdd.setTime(5, ApplicationUtil.convertUtilToSqlTime(flight.getDuration()));
				psAdd.setDouble(6, flight.getPrice());
				psAdd.setInt(7, flight.getAvailableSeat());
				psAdd.addBatch();
			}

			int[] rows = psAdd.executeBatch();
			if (rows != null && rows.length > 0) {
				status = true;
			}
			conn.commit();
		} catch (SQLException ex) {
			if (conn != null) {
				try {
					conn.rollback();
				} catch (SQLException e) {
					throw new FlightScheduleAdminSystemException(ex.getMessage(), ex.getCause());
				}
			}
			throw new FlightScheduleAdminSystemException(ex.getMessage(), ex.getCause());
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					throw new FlightScheduleAdminSystemException(e.getMessage(), e.getCause());
				}
			}
		}

		return status;
		// TODO CHANGE THIS RETURN TYPE

	}

	public Boolean updateAirFlightSchedules(List<AirFlightSchedule> flights) throws FlightScheduleAdminSystemException {
		// TODO add your code here
		Boolean status = false;
		try {
			conn = DBConnectionManager.getInstance().getConnection();
			conn.setAutoCommit(false);
			PreparedStatement psAdd = conn.prepareStatement(UPDATE_AIRFLIGHTDETAILS_DETAILS);
			for (AirFlightSchedule flight : flights) {
				psAdd.setTime(1, ApplicationUtil.convertUtilToSqlTime(flight.getDepartureTime()));
				psAdd.setTime(2, ApplicationUtil.convertUtilToSqlTime(flight.getArrivalTime()));
				psAdd.setTime(3, ApplicationUtil.convertUtilToSqlTime(flight.getDuration()));
				psAdd.setString(4, flight.getFlightId());
				psAdd.setDate(5, ApplicationUtil.convertUtilToSqlDate(flight.getFlightDepartureDate()));
				System.out.println(psAdd);
				psAdd.addBatch();
			}

			int[] rows = psAdd.executeBatch();
			if (rows != null && rows.length > 0) {
				status = true;
			}
			conn.commit();
		} catch (SQLException ex) {
			if (conn != null) {
				try {
					conn.rollback();
				} catch (SQLException e) {
					throw new FlightScheduleAdminSystemException(ex.getMessage(), ex.getCause());
				}
			}
			throw new FlightScheduleAdminSystemException(ex.getMessage(), ex.getCause());
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					throw new FlightScheduleAdminSystemException(e.getMessage(), e.getCause());
				}
			}
		}

		return status;
		// TODO CHANGE THIS RETURN TYPE

	}

	public Boolean findAirFlightSchedules(AirFlightSchedule schedule) throws FlightScheduleAdminSystemException {
		// TODO add your code here
		Boolean status = false;
		try {
			conn = DBConnectionManager.getInstance().getConnection();
			conn.setAutoCommit(false);
			PreparedStatement psFind = conn.prepareStatement(FIND_AIRFLIGHTDETAILS_BY_DAPARTURE_DATE_TIME);
			psFind.setString(1, schedule.getFlightId());
			psFind.setDate(2, ApplicationUtil.convertUtilToSqlDate(schedule.getFlightDepartureDate()));
			
			ResultSet rs = psFind.executeQuery();

			if (rs != null && rs.next()) {
				int rowCount = rs.getInt(1);
				if (rowCount > 0) {
					status = true;
				}

			}
		} catch (SQLException ex) {
			if (conn != null) {
				try {
					conn.rollback();
				} catch (SQLException e) {
					throw new FlightScheduleAdminSystemException(ex.getMessage(), ex.getCause());
				}
			}
			throw new FlightScheduleAdminSystemException(ex.getMessage(), ex.getCause());
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					throw new FlightScheduleAdminSystemException(e.getMessage(), e.getCause());
				}
			}
		}

		return status;
		// TODO CHANGE THIS RETURN TYPE

	}
}

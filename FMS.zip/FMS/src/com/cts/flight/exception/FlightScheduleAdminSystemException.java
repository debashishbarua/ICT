/***********************************************************************************************************
 * This class FlightScheduleAdminSystemException is as exception class.
 * 
 * DO NOT CHANGE THE CLASS NAME,  PUBLIC METHODS, SIGNATURE OF METHODS, EXCEPTION CLAUSES, RETURN TYPES
 * YOU CAN ADD ANY NUMBER OF PRIVATE METHODS TO MODULARIZE THE CODE
 * DO NOT SUBMIT THE CODE WITH COMPILATION ERRORS
 * DO TEST YOUR CODE USING MAIN METHOD 
 * CHANGE THE RETURN TYPE OF THE METHODS ONCE YOU BUILT THE LOGIC
 * DO NOT ADD ANY ADDITIONAL EXCEPTIONS IN THE THROWS CLAUSE OF THE METHOD. IF NEED BE, 
 * YOU CAN CATCH THEM AND THROW ONLY 
 * THE APPLICATION SPECIFIC EXCEPTION AS PER EXCEPTION CLAUSE
 *
************************************************************************************************************/

package com.cts.flight.exception;

public class FlightScheduleAdminSystemException extends Exception {
	
	private static final long serialVersionUID = -5459759544203601561L;

	public FlightScheduleAdminSystemException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	//TODO add your constructors here 
	
	
}

/***********************************************************************************************************
 * This class ApplicationUtil is used for any utility methods needed for service or dao classes
 * 
 * DO NOT CHANGE THE CLASS NAME,  PUBLIC METHODS, SIGNATURE OF METHODS, EXCEPTION CLAUSES, RETURN TYPES
 * YOU CAN ADD ANY NUMBER OF PRIVATE METHODS TO MODULARIZE THE CODE
 * DO NOT SUBMIT THE CODE WITH COMPILATION ERRORS
 * DO TEST YOUR CODE USING MAIN METHOD 
 * CHANGE THE RETURN TYPE OF THE METHODS ONCE YOU BUILT THE LOGIC
 * DO NOT ADD ANY ADDITIONAL EXCEPTIONS IN THE THROWS CLAUSE OF THE METHOD. IF NEED BE, 
 * YOU CAN CATCH THEM AND THROW ONLY THE APPLICATION SPECIFIC EXCEPTION AS PER EXCEPTION CLAUSE
 *
************************************************************************************************************/

package com.cts.flight.util;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.cts.flight.exception.FlightScheduleAdminSystemException;

public class ApplicationUtil {

	/**
	 * @param fileName
	 * @return List<String>
	 * @throws FlightScheduleAdminSystemException
	 */
	public static List<String> readFile(String fileName) throws FlightScheduleAdminSystemException {
		// TODO Add your logic here
		List<String> lines = new ArrayList<String>();
		if (fileName != null) {
			try (Stream<String> stream = Files.lines(Paths.get(fileName))) {

				lines = stream.filter(line -> line.startsWith("AF")).map(String::toUpperCase)
						.collect(Collectors.toList());

			} catch (IOException pe) {
				throw new FlightScheduleAdminSystemException(pe.getMessage(), pe.getCause());
			}
		}

		return lines;
	}

	/**
	 * @param util
	 *            Date
	 * @return sql Date
	 */
	public static java.sql.Date convertUtilToSqlDate(java.util.Date uDate) {
		// TODO Add your logic here
		java.sql.Date sDate = null;
		if (uDate != null) {
			sDate = new java.sql.Date(uDate.getTime());
		}
		return sDate;
		
	}

	/**
	 * @param util
	 *            Date
	 * @return sql Time
	 */
	public static java.sql.Time convertUtilToSqlTime(java.util.Date uDate) {
		// TODO Add your logic here
		java.sql.Time sTime = null;
		if (uDate != null) {
			sTime = new java.sql.Time(uDate.getTime());
		}
		return sTime;
	}

	/**
	 * @param inDate
	 * @return Date
	 */
	public static Date convertStringToTime(String inDate) {
		// TODO Add your logic here
		SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		dateFormat.setLenient(false);
		try {
			return dateFormat.parse(inDate);
		} catch (ParseException pe) {
			return null;
		}
	}

	/**
	 * @param inDate
	 * @return Date
	 */
	public static Date convertStringToDate(String inDate) {
		// TODO Add your logic here
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		dateFormat.setLenient(false);
		try {
			return dateFormat.parse(inDate);
		} catch (ParseException pe) {
			return null;
		}
	}

	/**
	 * @param time1
	 * @param time2
	 * @return Date
	 */
	public static Date timeDifference(Date time1, Date time2) {
		long diff = time2.getTime() - time1.getTime();
		long diffSeconds = diff / 1000 % 60;
		long diffMinutes = diff / (60 * 1000) % 60;
		long diffHours = diff / (60 * 60 * 1000) % 24;
		String strTime = diffHours + ":" + diffMinutes + ":" + diffSeconds;
		return convertStringToTime(strTime);

	}
}

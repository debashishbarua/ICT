/***********************************************************************************************************
 * This class DBConnectionManager is used acquire database connection
 * 
 * DO NOT CHANGE THE CLASS NAME,  PUBLIC METHODS, SIGNATURE OF METHODS, EXCEPTION CLAUSES, RETURN TYPES
 * YOU CAN ADD ANY NUMBER OF PRIVATE METHODS TO MODULARIZE THE CODE
 * DO NOT SUBMIT THE CODE WITH COMPILATION ERRORS
 * DO TEST YOUR CODE USING MAIN METHOD 
 * CHANGE THE RETURN TYPE OF THE METHODS ONCE YOU BUILT THE LOGIC
 * DO NOT ADD ANY ADDITIONAL EXCEPTIONS IN THE THROWS CLAUSE OF THE METHOD. IF NEED BE, 
 * YOU CAN CATCH THEM AND THROW ONLY THE APPLICATION SPECIFIC EXCEPTION AS PER EXCEPTION CLAUSE
 *
************************************************************************************************************/

package com.cts.flight.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cts.flight.exception.FlightScheduleAdminSystemException;

public class DBConnectionManager {

	private static DBConnectionManager instance;
	public static final String PROPERTY_FILE = "database.properties";
	public static final String DRIVER = "db.classname";
	public static final String URL = "db.url";
	public static final String USER_NAME = "db.username";
	public static final String PASSWORD = "db.password";

	private static Connection connection = null;
	private static Properties props = null;

	/**
	 * @throws FlightScheduleAdminSystemException
	 */
	private DBConnectionManager() throws FlightScheduleAdminSystemException {
		loadProperties();
		try {
			Class.forName(props.getProperty(DRIVER));
			connection = DriverManager.getConnection(props.getProperty(URL), props.getProperty(USER_NAME),
					props.getProperty(PASSWORD));
		} catch (ClassNotFoundException ex) {
			throw new FlightScheduleAdminSystemException("Could not find Driver class ", ex.getCause());
		} catch (SQLException e) {
			throw new FlightScheduleAdminSystemException("Database Connection Creation Failed", e.getCause());
		}
	}

	/**
	 * @return DBConnectionManager
	 * @throws FlightScheduleAdminSystemException
	 */
	public static DBConnectionManager getInstance() throws FlightScheduleAdminSystemException {
		// TODO Add your logic here
		try {
			if ((instance == null) || (instance.getConnection().isClosed())) {
				instance = new DBConnectionManager();
			}
		} catch (SQLException e) {
			throw new FlightScheduleAdminSystemException("Database Connection Creation Failed", e.getCause());
		}

		return instance; // TODO change this return value
	}

	/**
	 * @throws FlightScheduleAdminSystemException
	 */
	private void loadProperties() throws FlightScheduleAdminSystemException {
		FileInputStream inputStream = null;
		try {
			inputStream = new FileInputStream(PROPERTY_FILE);
			props = new Properties();
			props.load(inputStream);
		} catch (FileNotFoundException e) {
			throw new FlightScheduleAdminSystemException("Database Property File Not Found", e.getCause());
		} catch (IOException e) {
			throw new FlightScheduleAdminSystemException("Exception during property file I/O", e.getCause());
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException e) {
					throw new FlightScheduleAdminSystemException("Exception during property file I/O", e.getCause());
				}
			}
		}
	}

	/**
	 * @return Connection
	 */
	public Connection getConnection() {
		return connection;
	}

}

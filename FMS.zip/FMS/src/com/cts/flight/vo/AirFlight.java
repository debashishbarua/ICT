/***********************************************************************************************************
 * This class AirFlight is a value object for data transfer between Service and DAO layers
 * 
 * DO NOT CHANGE THE NAMES OR DATA TYPES OR VISIBILITY OF THE BELOW MEMBER VARIABLES
 * DO NOT CHANGE THE CLASS NAME,  PUBLIC METHODS, SIGNATURE OF METHODS, EXCEPTION CLAUSES, RETURN TYPES
 * YOU CAN ADD ANY NUMBER OF PRIVATE METHODS TO MODULARIZE THE CODE
 * DO NOT SUBMIT THE CODE WITH COMPILATION ERRORS
 * DO TEST YOUR CODE USING MAIN METHOD 
 * CHANGE THE RETURN TYPE OF THE METHODS ONCE YOU BUILT THE LOGIC
 * DO NOT ADD ANY ADDITIONAL EXCEPTIONS IN THE THROWS CLAUSE OF THE METHOD. IF NEED BE, 
 * YOU CAN CATCH THEM AND THROW ONLY THE APPLICATION SPECIFIC EXCEPTION AS PER EXCEPTION CLAUSE
 *
************************************************************************************************************/

package com.cts.flight.vo;

public class AirFlight {
	// DO NOT CHANGE THE NAMES OR DATA TYPES OR VISIBILITY OF THE BELOW MEMBER
	// VARIABLES
	private String flightId;
	private String airlineId;
	private String airlineName;
	private String fromLocation;
	private String toLocation;
	private int totalSeats;

	// TODO add your code here

}
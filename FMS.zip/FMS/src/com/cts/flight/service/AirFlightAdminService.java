/***********************************************************************************************************
 * This class AirFlightAdminService is used to handle business logic for the proposed system.
 * 
 * DO NOT CHANGE THE CLASS NAME,  PUBLIC METHODS, SIGNATURE OF METHODS, EXCEPTION CLAUSES, RETURN TYPES
 * YOU CAN ADD ANY NUMBER OF PRIVATE METHODS TO MODULARIZE THE CODE
 * DO NOT SUBMIT THE CODE WITH COMPILATION ERRORS
 * DO TEST YOUR CODE USING MAIN METHOD 
 * CHANGE THE RETURN TYPE OF THE METHODS ONCE YOU BUILT THE LOGIC
 * DO NOT ADD ANY ADDITIONAL EXCEPTIONS IN THE THROWS CLAUSE OF THE METHOD. IF NEED BE, 
 * YOU CAN CATCH THEM AND THROW ONLY THE APPLICATION SPECIFIC EXCEPTION AS PER EXCEPTION CLAUSE
 *
************************************************************************************************************/

package com.cts.flight.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cts.flight.dao.AirFlightScheduleDao;
import com.cts.flight.exception.FlightScheduleAdminSystemException;
import com.cts.flight.util.ApplicationUtil;
import com.cts.flight.vo.AirFlightSchedule;

public class AirFlightAdminService {

	private AirFlightScheduleDao dao = new AirFlightScheduleDao();

	private static final String INPUT_DELIMITER = ",";

	/**
	 * @param records
	 * @return List<AirFlightSchedule>
	 */
	public static List<AirFlightSchedule> buildAirFlightScheduleList(List<String> records) {
		// TODO Add your logic here
		List<AirFlightSchedule> airFlightSchedules = new ArrayList<AirFlightSchedule>();
		
		for (String record : records) {
			String[] flightSchedule = record.split(INPUT_DELIMITER);
			AirFlightSchedule airFlightSchedule = new AirFlightSchedule();

			Date departureTime = null;
			Date arrivalTime = null;

			if (flightSchedule[0] != null && flightSchedule[1] != null && flightSchedule[2] != null
					&& flightSchedule[3] != null && flightSchedule[4] != null && flightSchedule[5] != null) {
				airFlightSchedule.setFlightId(flightSchedule[0]);
				airFlightSchedule.setFlightDepartureDate(ApplicationUtil.convertStringToDate(flightSchedule[1]));
				departureTime = ApplicationUtil.convertStringToTime(flightSchedule[2]);
				arrivalTime = ApplicationUtil.convertStringToTime(flightSchedule[3]);
				if (arrivalTime.after(departureTime)) {
					airFlightSchedule.setDepartureTime(departureTime);
					airFlightSchedule.setArrivalTime(arrivalTime);
					// Calculating the duration
					Date duration = ApplicationUtil.timeDifference(departureTime, arrivalTime);
					airFlightSchedule.setDuration(duration);

					airFlightSchedule.setPrice(Double.parseDouble(flightSchedule[4]));
					airFlightSchedule.setAvailableSeat(Integer.parseInt(flightSchedule[5]));
					airFlightSchedules.add(airFlightSchedule);
				}
			}

		}
		return airFlightSchedules;

	}

	/**
	 * @param inputFeed
	 * @return Boolean
	 * @throws FlightScheduleAdminSystemException
	 */
	public Boolean addAirFlightSchedules(String inputFeed) throws FlightScheduleAdminSystemException {
		// TODO Add your logic here
		Boolean find = false;
		List<AirFlightSchedule> flightsInsert = new ArrayList<AirFlightSchedule>();
		List<AirFlightSchedule> flightsUpdate = new ArrayList<AirFlightSchedule>();
		
		List<AirFlightSchedule> flights = buildAirFlightScheduleList(ApplicationUtil.readFile(inputFeed));

		for (AirFlightSchedule airFlightSchedule : flights) {
			find = dao.findAirFlightSchedules(airFlightSchedule);
			if (find) {
				flightsUpdate.add(airFlightSchedule);
			} else {
				flightsInsert.add(airFlightSchedule);
			}
		}
		Boolean add = false;
		if (flightsInsert.isEmpty() && flightsUpdate.isEmpty()) {
			add = true;
		} else if (flightsInsert.isEmpty() && !flightsUpdate.isEmpty()) {
			add = dao.updateAirFlightSchedules(flightsUpdate);
		} else if (!flightsInsert.isEmpty() && flightsUpdate.isEmpty()) {
			add = dao.insertAirFlightSchedules(flightsInsert);
		} else if (!flightsInsert.isEmpty() && !flightsUpdate.isEmpty()) {
			add = dao.insertAirFlightSchedules(flightsInsert) && dao.updateAirFlightSchedules(flightsUpdate);
		}

		return add;

	}

}

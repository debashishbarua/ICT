package com.cts.flight.main;

import com.cts.flight.exception.FlightScheduleAdminSystemException;
import com.cts.flight.service.AirFlightAdminService;

public class MainApp {
	public static void main(String ag[]) {
		//TODO add your code here
		
		try {
			new AirFlightAdminService().addAirFlightSchedules("inputFeed.txt");
		} catch (FlightScheduleAdminSystemException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
